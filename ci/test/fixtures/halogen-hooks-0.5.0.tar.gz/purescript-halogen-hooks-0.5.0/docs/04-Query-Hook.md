# The Query Hook (useQuery)

This chapter hasn't been written yet, but you can read the corresponding entry in [the Hooks API reference](./07-Hooks-API.md).

It will offer a detailed walkthrough of using the query hook, which enables Halogen's querying feature for components.

In the meantime, you can see the [examples](../examples/Example/Hooks) to see this hook in action.
