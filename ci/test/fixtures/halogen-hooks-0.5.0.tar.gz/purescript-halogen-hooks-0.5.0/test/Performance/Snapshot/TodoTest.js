exports.result = {
  "hookAverage": {
    "totalTime": "478ms",
    "scriptTime": "333ms",
    "peakHeap": "13948kb",
    "averageHeap": "6594kb",
    "averageFPS": 20
  },
  "componentAverage": {
    "totalTime": "358ms",
    "scriptTime": "200ms",
    "peakHeap": "7045kb",
    "averageHeap": "3490kb",
    "averageFPS": 26
  }
}