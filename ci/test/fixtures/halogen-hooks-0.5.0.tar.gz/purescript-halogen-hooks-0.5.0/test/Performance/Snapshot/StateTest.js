exports.result = {
  "hookAverage": {
    "totalTime": "143ms",
    "scriptTime": "102ms",
    "peakHeap": "1894kb",
    "averageHeap": "746kb",
    "averageFPS": 18
  },
  "componentAverage": {
    "totalTime": "101ms",
    "scriptTime": "52ms",
    "peakHeap": "993kb",
    "averageHeap": "429kb",
    "averageFPS": 36
  }
}