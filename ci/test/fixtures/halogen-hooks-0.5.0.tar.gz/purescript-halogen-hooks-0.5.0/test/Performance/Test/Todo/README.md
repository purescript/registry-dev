# Performance Test: Todo

This test measures performance when nesting components several layers deep and updating from the root. It's intended to catch performance issues that would be relevant in the real world.

Actions:

- Add a new TODO
- Check and un-check a TODO
- Edit a TODO and save it
