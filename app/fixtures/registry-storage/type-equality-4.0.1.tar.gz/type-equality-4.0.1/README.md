# purescript-type-equality

[![Latest release](http://img.shields.io/github/release/purescript/purescript-type-equality.svg)](https://github.com/purescript/purescript-type-equality/releases)
[![Build status](https://github.com/purescript/purescript-type-equality/workflows/CI/badge.svg?branch=master)](https://github.com/purescript/purescript-type-equality/actions?query=workflow%3ACI+branch%3Amaster)
[![Pursuit](https://pursuit.purescript.org/packages/purescript-type-equality/badge)](https://pursuit.purescript.org/packages/purescript-type-equality)

Type equality constraints

## Installation

```
spago install type-equality
```

## Documentation

Module documentation is [published on Pursuit](http://pursuit.purescript.org/packages/purescript-type-equality).
